package tut12.greeting;

public class NotPossibleException extends RuntimeException {
    public NotPossibleException(String message) {
        super(message);
    }
}
