package tut12.greeting;

public enum Color {
    Blue, Red, Orange, Yellow, Purple
}
