package tut12.greeting;

public class GreetingConversation {

    public static void main(String[] args) {
        Person p1 = new Person(1, "Quan Dang");
        Person p2 = new Person(2, "Thuan Nguyen");
        MobilePhone m1 = new MobilePhone("Apple", "M-ABC-123", Color.Yellow, 2008, false);
        MobilePhone m2 = new MobilePhone("Apple", "M-DUX-872", Color.Red, 2021, true);
        p1.setPhone(m1);
        p2.setPhone(m2);
        p1.greet();
        p2.greet();
        System.out.println(p1);
        System.out.println(p2);
        // TODO: test more methods (all the public ones)
    }
}
