package tutorial_3;

public class ProductDemo {
    public static void main(String[] args) {
        Product pr = new Product();
        pr.input();
        pr.display();

        Product pr1 = new Product();
        pr1.input();
        pr1.display();
    }
}
